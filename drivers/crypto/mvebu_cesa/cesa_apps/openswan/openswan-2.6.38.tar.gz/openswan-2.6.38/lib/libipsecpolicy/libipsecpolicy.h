
extern u_int32_t ipsec_policy_seq(void);


